import {mkdir, readFile, writeFile, copyFile, rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const out = resolve(root, 'dist');
const assets = ['index.html', 'app.js', 'data.js', 'styles.css', 'update.js',
  'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png'];
const digester = createHash('sha256');
await rm(out, {recursive:true, force:true});
for (const name of assets){
  const content = await readFile(resolve(root, name));
  digester.update(name).update(content);
  await mkdir(dirname(resolve(out, name)), {recursive: true});
  await writeFile(resolve(out, name), content);
}
const hash = digester.digest('hex').slice(0, 16);
const revision = `revisehub-${hash}`;
let worker = await readFile(resolve(root, 'sw.js'), 'utf8');
worker = worker.replace(/const CACHE = '[^']+';/,
  `const CACHE = '${revision}';`);
if(!worker.includes(`const CACHE = '${revision}';`)) throw new Error('Cannot stamp service worker');
await writeFile(resolve(out, 'sw.js'), worker);
await writeFile(resolve(out, 'build-info.json'), JSON.stringify({version:hash}, null, 2)+'\n');
console.log(`ReviseHub build ${hash} ready in dist/`);
