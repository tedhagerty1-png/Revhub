(() => {
  'use strict';
  if (!('serviceWorker' in navigator) ||
      !(location.protocol === 'https:' || location.hostname === 'localhost')) return;

  const banner = document.getElementById('updateBanner');
  const apply = document.getElementById('applyUpdate');
  const later = document.getElementById('dismissUpdate');
  let registration = null;
  let dismissed = false;
  let activatedThisPage = false;

  function show() {
    if (!dismissed && banner) banner.hidden = false;
  }
  function ready() {
    if (registration?.waiting && navigator.serviceWorker.controller) show();
  }
  function poll() {
    if (navigator.onLine && document.visibilityState === 'visible') {
      registration?.update().catch(() => {});
    }
  }
  function watch(r) {
    registration = r;
    ready();
    r.addEventListener('updatefound', () => {
      const installing = r.installing;
      installing?.addEventListener('statechange', () => {
        if (installing.state === 'installed') ready();
      });
    });
    // Check for a new deploy each time the app is opened or foregrounded.
    poll();
  }

  apply?.addEventListener('click', () => {
    if (registration?.waiting) {
      apply.disabled = true;
      apply.textContent = 'Updating…';
      registration.waiting.postMessage({type:'SKIP_WAITING'});
    } else {
      // Fallback for browsers with unusual service-worker lifecycle behavior.
      location.reload();
    }
  });
  later?.addEventListener('click', () => {
    dismissed = true;
    banner.hidden = true;
  });
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (activatedThisPage) return;
    activatedThisPage = true;
    // Only auto-refresh after the user has requested the new worker.
    if (apply?.disabled) location.reload();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      dismissed = false;
      ready();
      poll();
    }
  });
  window.addEventListener('online', poll);
  setInterval(poll, 30 * 60 * 1000);
  // app.js registers the worker; using ready here reuses the same registration.
  navigator.serviceWorker.ready.then(watch).catch(() => {});
})();
