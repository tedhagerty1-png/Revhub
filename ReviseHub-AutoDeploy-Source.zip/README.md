# ReviseHub — automatic updates edition

An offline-first A-level revision progressive web app (PWA) for iOS Safari and Windows Edge/Chrome.

## What is included

- Edexcel History starter content: American Dream, South Africa under apartheid, British warfare c1790–1918
- Custom notes, evidence, topics, flashcards, quizzes, revision planner and focus timer
- Economics and Geography placeholders until exam boards are selected
- Local revision progress with JSON backup/export/import
- **Git-based automatic Netlify deployment** configuration (`netlify.toml`)
- **Automatic build versioning** (`scripts/build.mjs`): a fresh service worker is generated every time app files change
- Update notifications in the app; tap **Update now** when offered, so unfinished edits are not lost
- No login, online database, third-party analytics, or paid dependencies

## IMPORTANT: one-time account setup is required

The source code alone cannot activate deployment on your own hosting account. To keep the Home Screen icon and locally saved notes **use your existing Netlify project's same address**.

1. Unzip the **ReviseHub-AutoDeploy-Source.zip** file.
2. Create a GitHub repository (suggested name: `revisehub`) and upload **the files inside the unzipped folder** (including `netlify.toml` and `scripts/build.mjs`) to the **main** branch. Do not upload the ZIP as one file.
3. Sign in to [Netlify](https://app.netlify.com/), open your **existing ReviseHub site**, then find **Project configuration → Build & deploy / Developer settings → Continuous deployment → Repository → Link repository** (exact menu wording may vary).
4. Choose GitHub, authorise Netlify's GitHub access, select your `revisehub` repository, and select the **main** branch.
5. Netlify will read `netlify.toml`: build command `node scripts/build.mjs`, publish directory `dist`. Verify the initial deployment succeeds and the **existing Netlify URL remains the same**.
6. Each future commit/push to the repository's main branch will trigger a new deployment. iOS/Windows Home Screen apps discover updates when reopened or foregrounded; select **Update now** when the banner appears.

Reference: https://docs.netlify.com/build/git-workflows/repo-permissions-linking/

### Subsequent changes

Edit the project files in the GitHub repository, then **commit to main**. Netlify deploys the new version without a new ZIP upload or reinstall. If using ChatGPT to produce future changes, the updated files still need to be committed to the connected GitHub repository; ChatGPT cannot magically update Netlify just by answering in a chat.

### Local preview/testing

Requirements: Node.js 18+ and Python 3 (or any web server):

```sh
node scripts/build.mjs
cd dist
python -m http.server 8000
```

Open `http://localhost:8000`. HTTP on localhost is permitted for service workers; public installs require HTTPS.

## Privacy and saved work

The app stores personalised data under localStorage key `revisehub-al-v1`, separate from cached app files. Updating **the same HTTPS origin** doesn't intentionally remove it. New built-in topics and cards are merged by ID into saved courses, without resetting custom materials or exam-board settings. Service worker updates can be deferred when editing notes. As with any local browser storage, data may still be lost if browser data is cleared, private mode is used, or the website address changes. **Use Settings → Export backup periodically.** There is no live syncing between devices.

**Do not create a brand-new Netlify site URL if you want your existing installed iPhone app to update.** If the app was installed from a downloaded file rather than the website URL, you need to reinstall from the Netlify-hosted link after initial setup.

## Manual deployment fallback

The second file **ReviseHub-PWA-Publish-Ready.zip** contains only generated deployable files in its root; you can drag its extracted folder into Netlify Drop for one-off updates. **This is not automatic deployment.** The GitHub → Netlify connection above is what makes it automatic.

## Source

Pearson Edexcel A-Level History specification:
https://qualifications.pearson.com/content/dam/pdf/A%20Level/History/2015/Specification%20and%20sample%20assessments/9781446949993-gce2015-al-history-iss4.pdf
